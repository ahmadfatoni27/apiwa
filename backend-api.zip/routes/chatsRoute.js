import { Router } from 'express'
import { body, query } from 'express-validator'
import requestValidator from './../middlewares/requestValidator.js'
import sessionValidator from './../middlewares/sessionValidator.js'
import * as controller from './../controllers/chatsController.js'
import getMessages from './../controllers/getMessages.js'

const router = Router()

router.get('/', query('id').notEmpty(), requestValidator, sessionValidator, controller.getList)

router.get('/:jid', query('id').notEmpty(), requestValidator, sessionValidator, getMessages)

router.post(
    '/send',
    query('id').notEmpty(),
    body('receiver').notEmpty(),
    body('message').notEmpty(),
    requestValidator,
    sessionValidator,
    controller.send
)
router.post(
    '/sendMessageText',
    query('id').notEmpty(),
    body('jid').notEmpty(),
    body('message').notEmpty(),
    requestValidator,
    sessionValidator,
    controller.sendMessageText
)
router.post(
    '/sendImageUrl',
    query('id').notEmpty(),
    body('jid').notEmpty(),
    body('imageUrl').notEmpty(),
    requestValidator,
    sessionValidator,
    controller.sendImageUrl
)
router.post(
    '/sendDocumentUrl',
    query('id').notEmpty(),
    body('jid').notEmpty(),
    body('documentUrl').notEmpty(),
    requestValidator,
    sessionValidator,
    controller.sendDocumentUrl
)
router.post(
    '/sendVideoUrl',
    query('id').notEmpty(),
    body('jid').notEmpty(),
    body('videoUrl').notEmpty(),
    requestValidator,
    sessionValidator,
    controller.sendVideoUrl
)
router.post(
    '/sendLocation',
    query('id').notEmpty(),
    body('jid').notEmpty(),
    body('coordinates').notEmpty(),
    requestValidator,
    sessionValidator,
    controller.sendLocation
)
router.post(
    '/sendVCard',
    query('id').notEmpty(),
    body('jid').notEmpty(),
    body('fullname').notEmpty(),
    body('organization').notEmpty(),
    body('phoneNumber').notEmpty(),
    requestValidator,
    sessionValidator,
    controller.sendVCard
)
router.post(
    '/sendButtonMessage',
    query('id').notEmpty(),
    body('jid').notEmpty(),
    body('contentText').notEmpty(),
    body('footerText').notEmpty(),
    body('buttons').notEmpty(),
    requestValidator,
    sessionValidator,
    controller.sendButtonMessages
)
router.post(
    '/sendTemplateMessages',
    query('id').notEmpty(),
    body('jid').notEmpty(),
    body('text').notEmpty(),
    body('footer').notEmpty(),
    body('templateButtons').notEmpty(),
    requestValidator,
    sessionValidator,
    controller.sendTemplateMessages
)
router.post(
    '/sendListMessages',
    query('id').notEmpty(),
    body('jid').notEmpty(),
    body('title').notEmpty(),
    body('text').notEmpty(),
    body('footer').notEmpty(),
    body('buttonText').notEmpty(),
    body('sections').notEmpty(),
    requestValidator,
    sessionValidator,
    controller.sendListMessages
)



router.post('/send-bulk', query('id').notEmpty(), requestValidator, sessionValidator, controller.sendBulk)

export default router
