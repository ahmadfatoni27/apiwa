
const getmime = (extension)=> {
    // jpeg = "image/jpeg",
    // png = "image/png",
    // mp4 = "video/mp4",
    // gif = "video/gif",
    // pdf = "application/pdf",
    // ogg = "audio/ogg; codecs=opus",
    // mp4Audio = "audio/mp4",
    // /** for stickers */
    // webp = "image/webp"
  
    var mime;
    switch (extension) {
        case '.png':
            mime = "image/jpeg";
            break;
        case '.jpeg':
            mime = "image/jpeg";
            break;
        case '.jpg':
            mime = "image/jpeg";
            break;
        case '.JPG':
            mime = "image/jpg";
            break;
        case '.mp4':
            mime = "video/mp4";
            break;
        case '.gif':
            mime = "video/gif";
            break;
        case '.PNG':
            mime = "image/png";
            break;
        case '.JPEG':
            mime = "image/jpeg";
            break;
        case '.MP4':
            mime = "video/mp4";
            break;
        case '.GIF':
            mime = "video/gif";
            break;
  
        case '.pdf':
            mime = "application/pdf";
            break;
        case '.docx':
            mime = "application/vnd.openxmlformats-officedocument.wordprocessing";
            break;
        case '.doc':
            mime = "application/msword";
            break;
        case '.ogg':
            mime = "audio/ogg; codecs=opus";
            break;
        case '.webp':
            mime = "image/webp";
            break;
        case '.pkpass':
            mime = "application/vnd.apple.pkpass";
            break;
        default:
    }
  
    return mime;
  }
  const GetFilename = (url)=> {
    if (url) {
        var m = url.toString().match(/.*\/(.+?)\./);
        var extension = url.substring(url.lastIndexOf('.') + 1);
      
        if (m && m.length > 1) {
            var name = m[1]+""
            nama = name.replace("%20","-")
            return  name + '.' + extension;
        }

    }
    return "";
}
export {
    GetFilename,getmime
}