import { getSession, getfilename, getmime, getChatList, isExists, sendMessage, sendMessageWTyping, formatGroup } from './../whatsapp.js'

import response from './../response.js'
import path from 'path'

const getList = (req, res) => {
    return response(res, 200, true, '', getChatList(res.locals.sessionId, true))
}
const sendMessageText = async (req, res) => {
    const session = getSession(res.locals.sessionId)
    const receiver = formatGroup(req.body.jid)
    const { message } = req.body

    try {
        const exists = await isExists(session, receiver,true)

        if (!exists) {
            return response(res, 400, false, 'The group is not exists.')
        }
        var sendmessage = await sendMessageWTyping(session, receiver, { text: message })

        response(res, 200, true, 'The message has been successfully sent.', sendmessage)
    } catch {
        response(res, 500, false, 'Failed to send the message.')
    }
}
const sendImageUrl = async (req, res) => {
    const session = getSession(res.locals.sessionId)
    const receiver = formatGroup(req.body.jid)
    const { imageUrl, caption } = req.body


    try {
        const exists = await isExists(session, receiver,true)

        if (!exists) {
            return response(res, 400, false, 'The group is not exists.')
        }
        var messageoptions = {
            image: { url: imageUrl },
            caption: caption
        }
        var sendmessage = await sendMessageWTyping(session, receiver, messageoptions)

        response(res, 200, true, 'The message has been successfully sent.', sendmessage)
    } catch {
        response(res, 500, false, 'Failed to send the message.')
    }
}
const sendDocumentUrl = async (req, res) => {
    const session = getSession(res.locals.sessionId)
    const receiver = formatGroup(req.body.jid)
    const { documentUrl } = req.body
    const filename = getfilename(req.body.documentUrl)

    try {
        const exists = await isExists(session, receiver,true)

        if (!exists) {
            return response(res, 400, false, 'The group is not exists.')
        }



        var options = {
            document: { url: documentUrl },
            fileName: filename
        }

        var sendmessage = await sendMessageWTyping(session, receiver, options)


        response(res, 200, true, 'The message has been successfully sent.', sendmessage)
    } catch {
        response(res, 500, false, 'Failed to send the message.')
    }
}
const sendVideoUrl = async (req, res) => {
    const session = getSession(res.locals.sessionId)
    const receiver = formatGroup(req.body.jid)
    const { videoUrl, caption } = req.body
    const filename = getfilename(videoUrl)
    var extension = path.extname(filename)
    var mime = getmime(extension)
    console.log(filename)
    try {
        const exists = await isExists(session, receiver,true)

        if (!exists) {
            return response(res, 400, false, 'The group is not exists.')
        }
        
      

        var options = {
            video: { url: videoUrl },
            filename: filename,
            mimetype: mime,
            caption: caption
        }
        console.log(options)
        var sendmessage = await sendMessageWTyping(session, receiver, options)

        response(res, 200, true, 'The message has been successfully sent.', sendmessage)
    } catch {
        response(res, 500, false, 'Failed to send the message.')
    }
}
const sendLocation = async (req, res) => {
    const session = getSession(res.locals.sessionId)
    const receiver = formatGroup(req.body.jid)
    const { coordinates } = req.body

    try {
        const exists = await isExists(session, receiver,true)

        if (!exists) {
            return response(res, 400, false, 'The group is not exists.')
        }
        var options = {
            location: {
                degreesLatitude: coordinates.lat,
                degreesLongitude: coordinates.long
            }
        }


        var sendmessage = await sendMessageWTyping(session, receiver, options)

        response(res, 200, true, 'The message has been successfully sent.', sendmessage)
    } catch {
        response(res, 500, false, 'Failed to send the message.')
    }
}
const sendVCard = async (req, res) => {
    const session = getSession(res.locals.sessionId)
    const receiver = formatGroup(req.body.jid)
    const { fullname, organization, phoneNumber } = req.body

    try {
        const exists = await isExists(session, receiver,true)

        if (!exists) {
            return response(res, 400, false, 'The group is not exists.')
        }

        const vcard = 'BEGIN:VCARD\n' // metadata of the contact card
            + 'VERSION:3.0\n'
            + 'FN:' + fullname + '\n' // full name
            + 'ORG:' + organization + ';\n' // the organization of the contact
            + 'TEL;type=CELL;type=VOICE;waid=' + phoneNumber + ':+' + phoneNumber + '\n' // WhatsApp ID + phone number
            + 'END:VCARD'
        var options = {
            contacts: {
                displayName: fullname,
                contacts: [{ vcard }]
            }
        }
        var sendmessage = await sendMessageWTyping(session, receiver, options)

        response(res, 200, true, 'The message has been successfully sent.', sendmessage)
    } catch {
        response(res, 500, false, 'Failed to send the message.')
    }
}
const sendButtonMessages = async (req, res) => {
    const session = getSession(res.locals.sessionId)
    const receiver = formatGroup(req.body.jid)
    const { footerText, contentText, buttons, imageUrl } = req.body

    try {
        const exists = await isExists(session, receiver,true)

        if (!exists) {
            return response(res, 400, false, 'The group is not exists.')
        }
        var options
        if (imageUrl !== "" && imageUrl !== null) {
            options = {
                image: { url: imageUrl },
                text:contentText+"",
                footer: footerText + "",
                buttons: buttons,
                headerType: 4
            }
            

            var sendmessage = await sendMessageWTyping(session, receiver, options)

            response(res, 200, true, 'The message has been successfully sent.', sendmessage)
        } else {
            options = {
                
                text: contentText + "",
                footer: footerText + "",
                buttons: buttons,
                headerType: 1
            }
            console.log(options)
            var sendmessage = await sendMessageWTyping(session, receiver, options)

            response(res, 200, true, 'The message has been successfully sent.', sendmessage)
        }


    } catch {
        response(res, 500, false, 'Failed to send the message.')
    }
}
const sendTemplateMessages = async (req, res) => {
    const session = getSession(res.locals.sessionId)
    const receiver = formatGroup(req.body.jid)
    const { text, footer, templateButtons ,imageUrl} = req.body

    try {
        const exists = await isExists(session, receiver,true)

        if (!exists) {
            return response(res, 400, false, 'The group is not exists.')
        }
        if (imageUrl !== "" && imageUrl !== null) {
            var options = {
                text: text,
                footer: footer,
                templateButtons: templateButtons,
                image: { url: imageUrl }
            }
    
            var sendmessage = await sendMessageWTyping(session, receiver, options)
        }else{
            var options = {
                text: text,
                footer: footer,
                templateButtons: templateButtons 
            }
    
    
            var sendmessage = await sendMessageWTyping(session, receiver, options)
        }
       

        response(res, 200, true, 'The message has been successfully sent.', sendmessage)
    } catch {
        response(res, 500, false, 'Failed to send the message.')
    }
}
const sendListMessages = async (req, res) => {
    const session = getSession(res.locals.sessionId)
    const receiver = formatGroup(req.body.jid)
    const { text, footer, buttonText ,title,sections} = req.body

    try {
        const exists = await isExists(session, receiver,true)

        if (!exists) {
            return response(res, 400, false, 'The group is not exists.')
        }
      
            var options = {
                text: text,
                footer: footer,
                title:title,
                buttonText: buttonText,
                sections : sections
            };
    
            var sendmessage = await sendMessageWTyping(session, receiver, options)
    
       

        response(res, 200, true, 'The message has been successfully sent.', sendmessage)
    } catch {
        response(res, 500, false, 'Failed to send the message.')
    }
}

const send = async (req, res) => {
    const session = getSession(res.locals.sessionId)
    const receiver = formatGroup(req.body.receiver)
    const { message } = req.body

    try {
        const exists = await isExists(session, receiver, true)

        if (!exists) {
            return response(res, 400, false, 'The group is not exists.')
        }

        await sendMessage(session, receiver, { text: message })

        response(res, 200, true, 'The message has been successfully sent.')
    } catch {
        response(res, 500, false, 'Failed to send the message.')
    }
}

//event group


//end event
export { getList, send,sendMessageText, sendImageUrl, sendDocumentUrl, sendVideoUrl, sendVCard, sendLocation, sendButtonMessages, sendTemplateMessages,sendListMessages  }
